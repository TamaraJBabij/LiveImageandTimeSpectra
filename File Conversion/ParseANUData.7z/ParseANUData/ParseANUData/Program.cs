﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParseANUData
{
    class Program
    {
        static void Main(string[] args)
        {
            //if (args.Length != 0)
            //{
                Parser thisParser = new Parser(@"F:\Reaction Microscope\2015\29-09-2015, 0910");
            //}
            //else
            //{
              //  Console.WriteLine("Usage ParseANUData [Directory]");
            //}
        }
    }
}
